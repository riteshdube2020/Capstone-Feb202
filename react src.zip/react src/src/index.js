import React, { Component } from 'react';
import AppRouter from './routers/AppRouter';
import './App.css';
import getAppStore from './store/store';
import {Provider} from 'react-redux';
import ReactDOM from 'react-dom';
import {getFeedbacks} from './actions/feedbacks';

const store = getAppStore();

const template =(

<Provider store={store}>
        <AppRouter />
</Provider>);

store.dispatch(getFeedbacks()).then(()=>{
  ReactDOM.render(template,document.getElementById('root'));
});