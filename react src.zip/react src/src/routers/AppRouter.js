import React from 'react';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import Header from '../components/Header';
import DashBoard from '../components/DashBoard';
import NotFound from '../components/NotFound';
import AddFeedback from '../components/AddFeedback';
import EditFeedback from '../components/EditFeedback';
import UsersearchList from '../components/UsersearchList';
import Search from '../components/Search';

const AppRouter = () => (
    <BrowserRouter>
        <div className='container'>
            <Header />
            <Switch>
                <Route path="/" component={DashBoard} exact={true} />                              
                <Route path="/add" component={AddFeedback} />
                <Route path="/usersearch" component={UsersearchList} /> 
                <Route component={NotFound} />
            </Switch>
        </div>
    </BrowserRouter>
);

export default AppRouter;