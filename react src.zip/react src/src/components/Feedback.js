import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
//import { removeBook } from '../actions/books';
import { removeFeedback } from '../actions/feedbacks';
import { alert, buttons, jumbotron } from 'bootstrap-css';

const Feedback = ({ id, title, rating, userid, review,source, dispatch }) => (  
     

<div className="bd-example">
        {/* <Link to={`/feedback/${id}`}>
            <h4>ID: {id}</h4>
        </Link> */}
        <p ><strong>ID:</strong> {id}</p>
        <p><strong>Title:</strong> {title}</p>        
        <p><strong>Source:</strong> {source}</p>
        <p><strong>UserId:</strong> {userid}</p>        
        <p><strong>Rating:</strong>{rating}</p>

           
        {review && <p> <strong>Review:</strong> {review}</p>}     

        
        {/* disable delete function */}
        <button onClick={() => {
            dispatch(removeFeedback({ id }));
        }}>Delete</button>

        </div>
      


        
    

);

export default connect()(Feedback)