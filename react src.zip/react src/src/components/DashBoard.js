import React from 'react';
//import BookList from './BookList';
import FeedbackList from './FeedbackList';


const DashBoard = () => (
    <div className='container__list'>
        <FeedbackList />
    </div>
);

export default DashBoard;