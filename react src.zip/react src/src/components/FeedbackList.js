import React from 'react';
import { connect } from 'react-redux';
//import Book from './Book';
import Feedback from './Feedback';

const FeedbackList = (props) => (
    <div>
        Feedback List:
        <ul>
            
            {props.feedbacks.map(feedback => {
                return (
                    <li key={feedback.id}>
                        <Feedback {...feedback} />
                    </li>
                );
            })}
        </ul>

        

    </div>
);

const mapStateToProps = (state) => {
    return {
        feedbacks: state
    };
}

export default connect(mapStateToProps)(FeedbackList);