import React from 'react';
import { NavLink } from 'react-router-dom';
import { alert, buttons, jumbotron } from 'bootstrap-css';

const Header = () => (
    <header>
        {/* <h2>Capstone Project : User Feedback</h2> */}
        <h2><a href="#" className="navbar-link"><p  className="section-heading text-center" >Capstone Project: User Feedback</p></a></h2>
        
         <br></br>
         <br></br>
        
        {/* <div className='header__nav'>
           &nbsp;&nbsp;&nbsp;&nbsp; <NavLink to='/' activeClassName='activeNav' exact={true}>Dashboard</NavLink>&nbsp; &nbsp; &nbsp;&nbsp;
            <NavLink to='/add' activeClassName='activeNav'>Add-Feedback</NavLink>      &nbsp; &nbsp; &nbsp;&nbsp;     &nbsp;
            <NavLink to='/usersearch' activeClassName='activeNav'>Search By User</NavLink>&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;
            <NavLink to='/ratingsearch' activeClassName='activeNav'>Search By Rating</NavLink>&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;
        </div> */}

<div className='header__nav'>
			<ul className="nav nav-pills">
            <li role="presentation" className="active"><NavLink to='/' activeClassName='activeNav' exact={true}>Dashboard</NavLink></li>&nbsp; &nbsp; &nbsp;&nbsp;
            <li role="presentation"><NavLink to='/add' activeClassName='activeNav'>Add-Feedback</NavLink> </li>     &nbsp; &nbsp; &nbsp;&nbsp;     &nbsp;
            <li role="presentation"><NavLink to='/usersearch' activeClassName='activeNav'>Search By User</NavLink></li>&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;
            <li role="presentation"><NavLink to='/ratingsearch' activeClassName='activeNav'>Search By Rating</NavLink></li>&nbsp;&nbsp; &nbsp; &nbsp;&nbsp;
			</ul>
        </div>
    </header>


);

export default Header;