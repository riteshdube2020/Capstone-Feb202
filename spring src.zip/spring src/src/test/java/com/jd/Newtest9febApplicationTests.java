package com.jd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Newtest9febApplicationTests {

	@Test
	void contextLoads() {
	}

}
