package com.jd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Newtest9febApplication {

	public static void main(String[] args) {
		SpringApplication.run(Newtest9febApplication.class, args);
	}

}
